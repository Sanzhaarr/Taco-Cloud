package com.example.demo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.UUID;


import com.datastax.oss.driver.api.core.uuid.Uuids;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import org.hibernate.validator.constraints.CreditCardNumber;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Data
@Entity
@Table("orders")
public class TacoOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @ManyToOne
    private User user;

    @Id
    private String id;

    @Deprecated
    @NotBlank(message = "Delivery name is required")
    private String deliveryName;
    @Deprecated
    @NotBlank(message = "Street is required")
    private String deliveryStreet;
    @Deprecated
    @NotBlank(message = "City is required")
    private String deliveryCity;
    @Deprecated
    @NotBlank(message = "State is required")
    private String deliveryState;
    @Deprecated
    @NotBlank(message = "Zip code is required")
    private String deliveryZip;
    @CreditCardNumber(message = "Not a valid credit card number")
    private String ccNumber;
    @Pattern(regexp = "^(0[1-9]|1[0-2])([\\/])([2-9][0-9])$", message = "Must be formatted MM/YY")
    private String ccExpiration;
    @Digits(integer = 3, fraction = 0, message = "Invalid CVV")
    private String ccCVV;


    private List<Taco> tacos = new ArrayList<>();

    private Date placedAt = new Date();


    public void addTaco(TacoUDT taco) {
        this.tacos.add(taco);
    }
}