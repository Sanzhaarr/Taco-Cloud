package com.example.demo.authorization;

import com.example.demo.User;
import com.example.demo.data.UserRepository;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;

public class TacoUserRepository {

    public ApplicationRunner dataLoader(UserRepository repo, PasswordEncoder passwordEncoder) {
        return args -> {
            repo.save(
                    new User("sanzhar", PasswordEncoder.encode("password"), "ROLE_ADMIN"));
            repo.save(
                    new User("tacochef", PasswordEncoder.encode("password"), "ROLE_ADMIN"));
        };
    }

}
