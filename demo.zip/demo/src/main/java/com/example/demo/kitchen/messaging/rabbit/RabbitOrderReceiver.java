package com.example.demo.kitchen.messaging.rabbit;

import ch.qos.logback.classic.pattern.MessageConverter;
import com.example.demo.TacoOrder;
import jakarta.jms.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RabbitOrderReceiver {

    private RabbitTemplate rabbit;
    private MessageConverter converter;

    @Autowired
    public RabbitOrderReceiver(RabbitTemplate rabbit, MessageConverter converter) {
        this.rabbit = rabbit;
        this.converter = converter;
    }

    public TacoOrder receiveOrder() {
        Message message = rabbit.receive("tacocloud.order");
        return message != null ? (TacoOrder) converter.fromMessage(message) : null;
    }
}
