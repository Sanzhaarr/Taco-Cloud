package com.example.demo.messaging;

import jakarta.jms.Destination;

public interface OrderMessagingService {

    public void sendOrder();
}
